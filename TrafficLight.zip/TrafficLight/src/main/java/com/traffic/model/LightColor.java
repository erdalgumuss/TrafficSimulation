package com.traffic.model;

public enum LightColor {
    RED, YELLOW, GREEN
}
