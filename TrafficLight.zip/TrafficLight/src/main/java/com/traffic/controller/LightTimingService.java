package com.traffic.controller;

import java.util.Map;

public class LightTimingService {

    private static final int TOTAL_CYCLE_TIME = 120;
    private static final int YELLOW_TIME = 3;
    private static final int MIN_GREEN = 10;
    private static final int MAX_GREEN = 60;

    public Map<Direction, Integer> calculateGreenDurations(Map<Direction, Integer> vehicleCounts) {
        int totalVehicles = vehicleCounts.values().stream().mapToInt(i -> i).sum();
        int usableTime = TOTAL_CYCLE_TIME - (YELLOW_TIME * 4);

        return vehicleCounts.entrySet().stream().collect(
                java.util.stream.Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> {
                            if (totalVehicles == 0) return MIN_GREEN;
                            int duration = (entry.getValue() * usableTime) / totalVehicles;
                            return Math.max(MIN_GREEN, Math.min(MAX_GREEN, duration));
                        }
                )
        );
    }
}
